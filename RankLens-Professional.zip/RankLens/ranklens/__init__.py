"""RankLens educational ranking explainer."""
